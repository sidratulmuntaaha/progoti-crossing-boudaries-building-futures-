package com.example.progoti.adapter

data class MyLearningItem(
    val title: String,
    val imageResourceId: Int // Add this field
)